/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */



public class Boleta {
    private int ID_BOLETA;
    private String RUT_CLIENTE;
    private int ID_FORMA_PAGO;
    private int ID_ENTREGA;
    private int TOTAL;
    private String RUT;
    private int ID_FORMA_PAGO1;
    private int ID_ENTREGA1;

    public Boleta(int ID_BOLETA, String RUT_CLIENTE, int ID_FORMA_PAGO, int ID_ENTREGA, int TOTAL, String RUT, int ID_FORMA_PAGO1, int ID_ENTREGA1) {
        this.setID_BOLETA(ID_BOLETA);
        this.setRUT_CLIENTE(RUT_CLIENTE);
        this.setID_ENTREGA(ID_ENTREGA);
        this.setTOTAL(TOTAL);
        this.setRUT(RUT);
        this.setID_FORMA_PAGO1(ID_FORMA_PAGO1);
        this.setID_FORMA_PAGO(ID_FORMA_PAGO);
        this.setID_ENTREGA1(ID_ENTREGA1);
    }

    public Boleta() {
    }

    public int getID_BOLETA() {
        return ID_BOLETA;
    }

    public void setID_BOLETA(int ID_BOLETA) {
        this.ID_BOLETA = ID_BOLETA;
    }

    public String getRUT_CLIENTE() {
        return RUT_CLIENTE;
    }

    public void setRUT_CLIENTE(String RUT_CLIENTE) {
        if (RUT_CLIENTE.trim().length() >= 1 && RUT_CLIENTE.length() <= 13) {
            this.RUT_CLIENTE = RUT_CLIENTE;
        } else {
            System.out.println("El Rut del cliente es un campo obligatorio");
        }
    }

    public int getID_FORMA_PAGO() {
        return ID_FORMA_PAGO;
    }

    public void setID_FORMA_PAGO(int ID_FORMA_PAGO) {
        if (ID_FORMA_PAGO > 0 && ID_FORMA_PAGO <= 99999999) {
            this.ID_FORMA_PAGO = ID_FORMA_PAGO;
        } else {
            System.out.println("La Forma de Pago debe de conecter datos o debe de ser numerico");
        }
    }

    public int getID_ENTREGA() {
        return ID_ENTREGA;
    }

    public void setID_ENTREGA(int ID_ENTREGA) {
         if (ID_ENTREGA > 0 && ID_ENTREGA <= 999) {
            this.ID_ENTREGA = ID_ENTREGA;
        } else {
            System.out.println("La Entrega debe de conecter datos o debe de ser numerico");
        }
    }

    public int getTOTAL() {
        return TOTAL;
    }

    public void setTOTAL(int TOTAL) {
        if (TOTAL > 0 && TOTAL <= 99999999) {
            this.TOTAL = TOTAL;
        } else {
            System.out.println("El Total debe de conecter datos o debe de ser numerico");
        }
    }

    public String getRUT() {
        return RUT;
    }

    public void setRUT(String RUT) {
        if (RUT.trim().length() >= 1 && RUT.length() <= 13) {
            this.RUT = RUT;
        } else {
            System.out.println("El Rut es un campo obligatorio");
        }
    }

    public int getID_FORMA_PAGO1() {
        return ID_FORMA_PAGO1;
    }

    public void setID_FORMA_PAGO1(int ID_FORMA_PAGO1) {
        this.ID_FORMA_PAGO1 = ID_FORMA_PAGO1;
    }

    public int getID_ENTREGA1() {
        return ID_ENTREGA1;
    }

    public void setID_ENTREGA1(int ID_ENTREGA1) {
        this.ID_ENTREGA1 = ID_ENTREGA1;
    }
    
    

   
    
    
}
