/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Descripcion_Compra_Boleta {
    private int ID_DESCRIPCION_COMPRAR;
    private int ID_BOLETA;
    private int ID_PRODUCTO;
    private int CANTIDAD;
    private int VALOR_PRODUCTO;
    private int TOTAL_PRODUCTO;

    public Descripcion_Compra_Boleta(int ID_DESCRIPCION_COMPRAR, int ID_BOLETA, int ID_PRODUCTO, int CANTIDAD, int VALOR_PRODUCTO, int TOTAL_PRODUCTO) {
        this.setID_DESCRIPCION_COMPRAR(ID_DESCRIPCION_COMPRAR);
        this.setID_BOLETA(ID_BOLETA);
        this.setID_PRODUCTO(ID_PRODUCTO);
        this.setCANTIDAD(CANTIDAD);
        this.setVALOR_PRODUCTO(VALOR_PRODUCTO);
        this.setTOTAL_PRODUCTO(TOTAL_PRODUCTO);
    }

    public Descripcion_Compra_Boleta() {
    }

    public int getID_DESCRIPCION_COMPRAR() {
        return ID_DESCRIPCION_COMPRAR;
    }

    public void setID_DESCRIPCION_COMPRAR(int ID_DESCRIPCION_COMPRAR) {
        this.ID_DESCRIPCION_COMPRAR = ID_DESCRIPCION_COMPRAR;
    }

    public int getID_BOLETA() {
        return ID_BOLETA;
    }

    public void setID_BOLETA(int ID_BOLETA) {
        this.ID_BOLETA = ID_BOLETA;
    }

    public int getID_PRODUCTO() {
        return ID_PRODUCTO;
    }

    public void setID_PRODUCTO(int ID_PRODUCTO) {
        this.ID_PRODUCTO = ID_PRODUCTO;
    }

    public int getCANTIDAD() {
        return CANTIDAD;
    }

    public void setCANTIDAD(int CANTIDAD) {
        if (CANTIDAD > 0 && CANTIDAD <= 99999999) {
            this.CANTIDAD = CANTIDAD;
        } else {
            System.out.println("La CANTIDAD debe de conecter datos o debe de ser numerico");
        }
    }

    public int getVALOR_PRODUCTO() {
        return VALOR_PRODUCTO;
    }

    public void setVALOR_PRODUCTO(int VALOR_PRODUCTO) {
       if (VALOR_PRODUCTO > 0 && VALOR_PRODUCTO <= 99999999) {
            this.VALOR_PRODUCTO = VALOR_PRODUCTO;
        } else {
            System.out.println("El VALOR Del PRODUCTO debe de conecter datos o debe de ser numerico");
        }
    }

    public int getTOTAL_PRODUCTO() {
        return TOTAL_PRODUCTO;
    }

    public void setTOTAL_PRODUCTO(int TOTAL_PRODUCTO) {
        if (TOTAL_PRODUCTO > 0 && TOTAL_PRODUCTO <= 99999999) {
            this.TOTAL_PRODUCTO = TOTAL_PRODUCTO;
        } else {
            System.out.println("El TOTAL Del PRODUCTO debe de conecter datos o debe de ser numerico");
        }
    }
    
            
}
