/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author josemanuel
 */
public class Usuario {

    private String ID_USUARIO;
    private String USER;
    private String PASS;
    private int ID_NIVEL_USUARIO;

    public Usuario() {
    }

    
    public Usuario(String ID_USUARIO, String USER, String PASS, int ID_NIVEL_USUARIO) {
        this.setID_USUARIO(ID_USUARIO);
        this.setUSER(USER);
        this.setPASS(PASS);
        this.setID_NIVEL_USUARIO(ID_NIVEL_USUARIO);
    }

    public String getID_USUARIO() {
        return ID_USUARIO;
    }

    public String getUSER() {
        return USER;
    }

    public String getPASS() {
        return PASS.toLowerCase();
    }

    public int getID_NIVEL_USUARIO() {
        return ID_NIVEL_USUARIO;
    }

    public void setID_USUARIO(String ID_USUARIO) {
        this.ID_USUARIO = ID_USUARIO;
    }

    public void setUSER(String USER) {
        if (USER.trim().length() > 0 && USER.length() <= 30) {
            this.USER = USER;
        } else {
            System.out.println("El nombre de usuario es un campo obligatorio");
        }

    }

    public void setPASS(String PASS) {
        if (PASS.trim().length() > 0 && USER.length() <= 30) {
            this.PASS = PASS.toLowerCase();
        } else {
            System.out.println("La contraseña es un campo obligatorio");
        }

    }

    public void setID_NIVEL_USUARIO(int ID_NIVEL_USUARIO) {
        /*
        try {
            if (ID_NIVEL_USUARIO > 0 && ID_NIVEL_USUARIO <= 999) {*/
                this.ID_NIVEL_USUARIO = ID_NIVEL_USUARIO;/*
            } else {
                System.out.println("Error critico con el id del nivel del usuario ingresando: "+ID_NIVEL_USUARIO);
            }

        } catch (Exception e) {
            System.out.println("Error critico con el id del nivel del usuario 2: " + e.getMessage());
        }*/

    }

}
