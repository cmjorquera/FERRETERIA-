/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Detalle_Orden_Compra {
    private int ID_DETALLE;
    private int ID_ORDEN_COMPRA;
    private int ID_PRODUCTO;
    private int CANTIDAD;
    private int TOTAL;

    public Detalle_Orden_Compra(int ID_DETALLE, int ID_ORDEN_COMPRA, int ID_PRODUCTO, int CANTIDAD, int TOTAL) {
       this.setID_DETALLE(ID_DETALLE);
        this.setID_ORDEN_COMPRA(ID_ORDEN_COMPRA);
        this.setID_PRODUCTO(ID_PRODUCTO);
        this.setCANTIDAD(CANTIDAD);
        this.setTOTAL(TOTAL);
    }

    public Detalle_Orden_Compra() {
    }

    public int getID_DETALLE() {
        return ID_DETALLE;
    }

    public void setID_DETALLE(int ID_DETALLE) {
        this.ID_DETALLE = ID_DETALLE;
    }

    public int getID_ORDEN_COMPRA() {
        return ID_ORDEN_COMPRA;
    }

    public void setID_ORDEN_COMPRA(int ID_ORDEN_COMPRA) {
        this.ID_ORDEN_COMPRA = ID_ORDEN_COMPRA;
    }

    public int getID_PRODUCTO() {
        return ID_PRODUCTO;
    }

    public void setID_PRODUCTO(int ID_PRODUCTO) {
        this.ID_PRODUCTO = ID_PRODUCTO;
    }

    public int getCANTIDAD() {
        return CANTIDAD;
    }

    public void setCANTIDAD(int CANTIDAD) {
        if (CANTIDAD > 0 && CANTIDAD <= 99999999) {
            this.CANTIDAD = CANTIDAD;
        } else {
            System.out.println("La CANTIDAD debe de conecter datos o debe de ser numerico");
        }
    }

    public int getTOTAL() {
        return TOTAL;
    }

    public void setTOTAL(int TOTAL) {
        if (TOTAL > 0 && TOTAL <= 99999999) {
            this.TOTAL = TOTAL;
        } else {
            System.out.println("El TOTAL debe de conecter datos o debe de ser numerico");
        }
    }
    
    
}
