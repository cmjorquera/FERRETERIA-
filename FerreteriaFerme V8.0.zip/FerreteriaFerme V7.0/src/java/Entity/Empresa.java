/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Empresa {
    private String RUT;
    private String NOMBRE;
    private String DIRECCION;
    private String COMUNA;
    private String EMAIL;

    public Empresa(String RUT, String NOMBRE, String DIRECCION, String COMUNA, String EMAIL) {
        this.setRUT(RUT);
        this.setNOMBRE(NOMBRE);
        this.setDIRECCION(DIRECCION);
        this.setCOMUNA(COMUNA);
        this.setEMAIL(EMAIL);
    }

    public Empresa() {
    }

    public String getRUT() {
        return RUT;
    }

    public void setRUT(String RUT) {
        if (RUT.trim().length() >= 1 && RUT.length() <= 13) {
            this.RUT = RUT;
        } else {
            System.out.println("El Rut es un campo obligatorio");
        }
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public void setNOMBRE(String NOMBRE) {
         if (NOMBRE.trim().length() >= 1 && NOMBRE.length() <= 30) {
            this.NOMBRE = NOMBRE;
        } else {
            System.out.println("El Nombre es un campo obligatorio");
        }
    }

    public String getDIRECCION() {
        return DIRECCION;
    }

    public void setDIRECCION(String DIRECCION) {
        if (DIRECCION.trim().length() >= 1 && DIRECCION.length() <= 30) {
            this.DIRECCION = DIRECCION;
        } else {
            System.out.println("La DIRECCION es un campo obligatorio");
        }
    }

    public String getCOMUNA() {
        return COMUNA;
    }

    public void setCOMUNA(String COMUNA) {
        if (COMUNA.trim().length() >= 1 && COMUNA.length() <= 30) {
            this.COMUNA = COMUNA;
        } else {
            System.out.println("La COMUNA es un campo obligatorio");
        }
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public void setEMAIL(String EMAIL) {
        if (EMAIL.trim().length() >= 1 && EMAIL.length() <= 30) {
            this.EMAIL = EMAIL;
        } else {
            System.out.println("El EMAIL es un campo obligatorio");
        }
    }
    
    
}
