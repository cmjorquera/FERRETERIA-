/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author josemanuel
 */
public class Familia_Producto {

    private int ID_FAMILIA_PRODUCTO;
    private String DESCRIPCION;

    public Familia_Producto(int ID_FAMILIA_PRODUCTO, String DESCRIPCION) {
        this.setID_FAMILIA_PRODUCTO(ID_FAMILIA_PRODUCTO);
        this.setDESCRIPCION(DESCRIPCION);
    }

    public int getID_FAMILIA_PRODUCTO() {
        return ID_FAMILIA_PRODUCTO;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    //validaciones
    public void setID_FAMILIA_PRODUCTO(int ID_FAMILIA_PRODUCTO) {

        this.ID_FAMILIA_PRODUCTO = ID_FAMILIA_PRODUCTO;

    }

    public void setDESCRIPCION(String DESCRIPCION) {
        if (DESCRIPCION.trim().length() >= 1 && DESCRIPCION.length() <= 30) {
            this.DESCRIPCION = DESCRIPCION;
        } else {
            System.out.println("la descripcion es un campo obligatorio");
        }

    }

}
