/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author josemanuel
 */
public class Proveedor {

    private int ID_PROVEEDOR;
    private String RUT_PROVEEDOR;
    private String NOMBRE;
    private String CELULAR;
    private String RUBRO;

    public Proveedor(int ID_PROVEEDOR, String RUT_PROVEEDOR, String NOMBRE, String CELULAR, String RUBRO) {
        this.setID_PROVEEDOR(ID_PROVEEDOR);
        this.setRUT_PROVEEDOR(RUT_PROVEEDOR);
        this.setNOMBRE(NOMBRE);
        this.setCELULAR(CELULAR);
        this.setRUBRO(RUBRO);
    }

    public int getID_PROVEEDOR() {
        return ID_PROVEEDOR;
    }

    public String getRUT_PROVEEDOR() {
        return RUT_PROVEEDOR;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public String getCELULAR() {
        return CELULAR;
    }

    public String getRUBRO() {
        return RUBRO;
    }

    public void setID_PROVEEDOR(int ID_PROVEEDOR) {
        this.ID_PROVEEDOR = ID_PROVEEDOR;
    }

    public void setRUT_PROVEEDOR(String RUT_PROVEEDOR) {
        if (RUT_PROVEEDOR.trim().length() > 0 && RUT_PROVEEDOR.length() <= 13) {
            this.RUT_PROVEEDOR = RUT_PROVEEDOR;
        } else {
            System.out.println("Ingrese un rut valido");
        }

    }

    public void setNOMBRE(String NOMBRE) {
        if (NOMBRE.trim().length() > 0 && NOMBRE.length() <= 30) {
            this.NOMBRE = NOMBRE;
        } else {
            System.out.println("Ingrese un nombre Correcto");
        }
    }

    public void setCELULAR(String CELULAR) {
        if (CELULAR.trim().length() > 0 && CELULAR.length() < 13) {
            this.CELULAR = CELULAR;
        } else {
            System.out.println("Ingrese un celular valido");
        }
    }

    public void setRUBRO(String RUBRO) {
        if (RUBRO.trim().length() > 0 && RUBRO.length() <= 30) {
            this.RUBRO = RUBRO;
        } else {
            System.out.println("Ingrese un rubro correcto");
        }
    }

}
