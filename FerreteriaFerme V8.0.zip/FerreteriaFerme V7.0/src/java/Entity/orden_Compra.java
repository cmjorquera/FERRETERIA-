/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author josemanuel
 */
public class orden_Compra {

    private int ID_ORDEN_COMPRA;
    private int ID_PROVEEDOR;
    private String RECIBIDO;

    public orden_Compra(int ID_ORDEN_COMPRA, int ID_PROVEEDOR, String RECIBIDO) {
        this.setID_ORDEN_COMPRA(ID_ORDEN_COMPRA);
        this.setID_PROVEEDOR(ID_PROVEEDOR);
        this.setRECIBIDO(RECIBIDO);
    }

    public int getID_ORDEN_COMPRA() {
        return ID_ORDEN_COMPRA;
    }

    public int getID_PROVEEDOR() {
        return ID_PROVEEDOR;
    }

    public String getRECIBIDO() {
        return RECIBIDO;
    }

    public void setID_ORDEN_COMPRA(int ID_ORDEN_COMPRA) {
        this.ID_ORDEN_COMPRA = ID_ORDEN_COMPRA;
    }

    public void setID_PROVEEDOR(int ID_PROVEEDOR) {
        if (ID_PROVEEDOR > 0 && ID_PROVEEDOR <= 999) {
            this.ID_PROVEEDOR = ID_PROVEEDOR;
        } else {
            System.out.println("Error id proveedor");
        }

    }

    public void setRECIBIDO(String RECIBIDO) {
        if (RECIBIDO.trim().length() == 1) {
            this.RECIBIDO = RECIBIDO;
        } else {
            System.out.println("El recibo debe de tener un solo caracter");
        }

    }

}
