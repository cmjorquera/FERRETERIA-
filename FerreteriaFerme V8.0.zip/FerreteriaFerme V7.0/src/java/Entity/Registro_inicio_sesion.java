/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author josemanuel
 */
public class Registro_inicio_sesion {

    private int ID_REGISTRO;
    private String FECHA;
    private String ID_USUARIO;

    public Registro_inicio_sesion(int ID_REGISTRO, String FECHA, String ID_USUARIO) {
        this.setID_REGISTRO(ID_REGISTRO);
        this.setFECHA(FECHA);
        this.setID_USUARIO(ID_USUARIO);
    }

    public int getID_REGISTRO() {
        return ID_REGISTRO;
    }

    public String getFECHA() {
        return FECHA;
    }

    public String getID_USUARIO() {
        return ID_USUARIO;
    }

    public void setID_REGISTRO(int ID_REGISTRO) {
        this.ID_REGISTRO = ID_REGISTRO;
    }

    public void setFECHA(String FECHA) {
        boolean resp = validarFecha(FECHA);
        if (resp) {
            this.FECHA = FECHA;
        } else {
            System.out.println("La Fecha es Invalida");
        }
    }

    public void setID_USUARIO(String ID_USUARIO) {
        if (ID_USUARIO.trim().length() == 13) {
            this.ID_USUARIO = ID_USUARIO;
        }else{
            System.out.println("El rut del Usuario es invalido");
        }

    }

    /// validacion de la fecha
    public boolean validarFecha(String fecha) {
        try {
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            formatoFecha.setLenient(false);
            formatoFecha.parse(fecha);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
}
