/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/**
 *
 * @author Duoc
 */
public class Cliente {
    private String RUT;
    private String NOMBRE;
    private String APELLIDO;
    private String DIRECCION;
    private String COMUNA;
    private String EMAIL;
    private String FECHA_NACIMIENTO;
    private int ID_USUARIO;
    private int ID_NIVEL_USUARIO1;

    public Cliente(String RUT, String NOMBRE, String APELLIDO, String DIRECCION, String COMUNA, String EMAIL, String FECHA_NACIMIENTO, int ID_USUARIO, int ID_NIVEL_USUARIO1) {
        this.setRUT(RUT);
        this.setNOMBRE (NOMBRE);
        this.setAPELLIDO(APELLIDO);
        this.setDIRECCION(DIRECCION);
        this.setCOMUNA(COMUNA);
        this.setEMAIL(EMAIL);
        this.setFECHA_NACIMIENTO(FECHA_NACIMIENTO);
        
    }

    public Cliente() {
    }

    
    public String getRUT() {
        return RUT;
    }

    public void setRUT(String RUT) {
        if (RUT.trim().length() >= 1 && RUT.length() <= 13) {
            this.RUT = RUT;
        } else {
            System.out.println("El Rut es un campo obligatorio");
        }
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public void setNOMBRE(String NOMBRE) {
        if (NOMBRE.trim().length() >= 1 && NOMBRE.length() <= 30) {
            this.NOMBRE = NOMBRE;
        } else {
            System.out.println("El Nombre es un campo obligatorio");
        }
    }

    public String getAPELLIDO() {
        return APELLIDO;
    }

    public void setAPELLIDO(String APELLIDO) {
        if (APELLIDO.trim().length() >= 1 && APELLIDO.length() <= 30) {
            this.APELLIDO = APELLIDO;
        } else {
            System.out.println("El APELLIDO es un campo obligatorio");
        }
    }

    public String getDIRECCION() {
        return DIRECCION;
    }

    public void setDIRECCION(String DIRECCION) {
        if (DIRECCION.trim().length() >= 1 && DIRECCION.length() <= 30) {
            this.DIRECCION = DIRECCION;
        } else {
            System.out.println("La DIRECCION es un campo obligatorio");
        }
    }

    public String getCOMUNA() {
        return COMUNA;
    }

    public void setCOMUNA(String COMUNA) {
        if (COMUNA.trim().length() >= 1 && COMUNA.length() <= 30) {
            this.COMUNA = COMUNA;
        } else {
            System.out.println("La COMUNA es un campo obligatorio");
        }
    }

    public String getEMAIL() {
        return EMAIL;
    }

    public void setEMAIL(String EMAIL) {
        if (EMAIL.trim().length() >= 1 && EMAIL.length() <= 30) {
            this.EMAIL = EMAIL;
        } else {
            System.out.println("El EMAIL es un campo obligatorio");
        }
    }

    public String getFECHA_NACIMIENTO() {
        return FECHA_NACIMIENTO;
    }

    public void setFECHA_NACIMIENTO(String FECHA_NACIMIENTO) {
       this.FECHA_NACIMIENTO = FECHA_NACIMIENTO;
    }

    public int getID_USUARIO() {
        return ID_USUARIO;
    }

    public void setID_USUARIO(int ID_USUARIO) {
        this.ID_USUARIO = ID_USUARIO;
    }

    public int getID_NIVEL_USUARIO1() {
        return ID_NIVEL_USUARIO1;
    }

    public void setID_NIVEL_USUARIO1(int ID_NIVEL_USUARIO1) {
        this.ID_NIVEL_USUARIO1 = ID_NIVEL_USUARIO1;
    }





   
    
    
}
