/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author josemanuel
 */
public class Producto {

    private String ID_PRODUCTO;
    private String ID_PROVEEDOR;
    private int ID_FAMILIA_PRODUCTO;
    private int ID_TIPO_PRODUCTO;
    private String FECHA_VENCIMIENTO;
    private String DESCRIPCION;
    private int STOCK;
    private int STOCK_CRITICO;
    private int PRECIO;
    private String Img;

    public Producto(String ID_PRODUCTO, String ID_PROVEEDOR, int ID_FAMILIA_PRODUCTO, int ID_TIPO_PRODUCTO, String FECHA_VENCIMIENTO, String DESCRIPCION, int STOCK, int STOCK_CRITICO, int PRECIO, String Img) {
        this.setID_PRODUCTO(ID_PRODUCTO);
        this.setID_PROVEEDOR(ID_PROVEEDOR);
        this.setID_FAMILIA_PRODUCTO(ID_FAMILIA_PRODUCTO);
        this.setID_TIPO_PRODUCTO(ID_TIPO_PRODUCTO);
        this.setFECHA_VENCIMIENTO(FECHA_VENCIMIENTO);
        this.setDESCRIPCION(DESCRIPCION);
        this.setSTOCK(STOCK);
        this.setSTOCK_CRITICO(STOCK_CRITICO);
        this.setPRECIO(PRECIO);
        this.setImg(Img);
    }

    public String getImg() {
        return Img;
    }

    public void setImg(String Img) {
        this.Img = Img;
    }

    public String getID_PRODUCTO() {
        return GenerarCodigo(ID_PROVEEDOR, ID_FAMILIA_PRODUCTO, FECHA_VENCIMIENTO);
    }

    public String getID_PROVEEDOR() {
        return ID_PROVEEDOR;
    }

    public int getID_FAMILIA_PRODUCTO() {
        return ID_FAMILIA_PRODUCTO;
    }

    public int getID_TIPO_PRODUCTO() {
        return ID_TIPO_PRODUCTO;
    }

    public String getFECHA_VENCIMIENTO() {
        return FECHA_VENCIMIENTO;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public int getSTOCK() {
        return STOCK;
    }

    public int getSTOCK_CRITICO() {
        return STOCK_CRITICO;
    }

    public int getPRECIO() {
        return PRECIO;
    }

    public void setID_PRODUCTO(String ID_PRODUCTO) {
        this.ID_PRODUCTO = ID_PRODUCTO;
    }

    public void setID_PROVEEDOR(String ID_PROVEEDOR) {
        if (ID_PROVEEDOR.length() > 0 && ID_PROVEEDOR.trim().length() <= 999) {
            this.ID_PROVEEDOR = ID_PROVEEDOR;
        } else {
            System.out.println("A ocurrido un error inesperado con el codigo del proveedor");
        }

    }

    public void setID_FAMILIA_PRODUCTO(int ID_FAMILIA_PRODUCTO) {
        if (ID_FAMILIA_PRODUCTO > 0 && ID_FAMILIA_PRODUCTO <= 999) {
            this.ID_FAMILIA_PRODUCTO = ID_FAMILIA_PRODUCTO;
        } else {
            System.out.println("A ocurrido un error inesperado con el codigo de la Familia del Producto");
        }

    }

    public void setID_TIPO_PRODUCTO(int ID_TIPO_PRODUCTO) {
        if (ID_TIPO_PRODUCTO > 0 && ID_TIPO_PRODUCTO <= 999) {
            this.ID_TIPO_PRODUCTO = ID_TIPO_PRODUCTO;
        } else {
            System.out.println("A ocurrido un error inesperado con el codigo del tipo del producto");
        }
    }

    public void setFECHA_VENCIMIENTO(String FECHA_VENCIMIENTO) {
        this.FECHA_VENCIMIENTO = FECHA_VENCIMIENTO;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        if (DESCRIPCION.trim().length() >= 1 && DESCRIPCION.length() <= 30) {
            this.DESCRIPCION = DESCRIPCION;
        } else {
            System.out.println("la descripcion es un campo obligatorio");
        }
    }

    public void setSTOCK(int STOCK) {
        if (STOCK > 0 && STOCK <= 99999999) {
            this.STOCK = STOCK;
        } else {
            System.out.println("El stock debe de conecter datos o debe de ser numerico");
        }

    }

    public void setSTOCK_CRITICO(int STOCK_CRITICO) {
        if (STOCK > 0 && STOCK <= 999999) {
            this.STOCK_CRITICO = STOCK_CRITICO;
        } else {
            System.out.println("El stock Critico debe de conecter datos o debe de ser numerico");
        }
    }

    public void setPRECIO(int PRECIO) {
        if (PRECIO > 0 && PRECIO <= 999999) {
            this.PRECIO = PRECIO;
        } else {
            System.out.println("Debe de ingresar Solo numeros");
        }

    }

    private String GenerarCodigo(String rut, int familia, String fecha) {
        String codigo1 = rut.replaceAll("\\.", "").substring(0, 3);
        String codigo2 = "00" + familia;

        //cambiar la fecha
        String codigo3 = fecha.replaceAll("-", "");
        String codigo4 = "00";

        return codigo1 + "-" + codigo2 + "-" + codigo3 + "-" + codigo4;
    }

}
