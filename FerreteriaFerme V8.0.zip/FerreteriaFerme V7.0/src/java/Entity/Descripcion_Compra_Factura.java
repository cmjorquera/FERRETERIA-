/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Descripcion_Compra_Factura {
    private int ID_DESCRIPCION_COMPRA;
    private int ID_FACTURA;
    private int ID_PRODUCTO;
    private int CANTIDAD;
    private int VALOR_PRODUCTO;
    private int TOTAL_PRODUCTO;

    public Descripcion_Compra_Factura(int ID_DESCRIPCION_COMPRA, int ID_FACTURA, int ID_PRODUCTO, int CANTIDAD, int VALOR_PRODUCTO, int TOTAL_PRODUCTO) {
        this.setID_DESCRIPCION_COMPRA(ID_DESCRIPCION_COMPRA);
        this.setID_FACTURA(ID_FACTURA);
         this.setID_PRODUCTO(ID_PRODUCTO);
        this.setCANTIDAD(CANTIDAD);
        this.setVALOR_PRODUCTO(VALOR_PRODUCTO);
        this.setTOTAL_PRODUCTO(TOTAL_PRODUCTO);
       
    }

    public Descripcion_Compra_Factura() {
    }

    public int getID_DESCRIPCION_COMPRA() {
        return ID_DESCRIPCION_COMPRA;
    }

    public void setID_DESCRIPCION_COMPRA(int ID_DESCRIPCION_COMPRA) {
        this.ID_DESCRIPCION_COMPRA = ID_DESCRIPCION_COMPRA;
    }

    public int getID_FACTURA() {
        return ID_FACTURA;
    }

    public void setID_FACTURA(int ID_FACTURA) {
        this.ID_FACTURA = ID_FACTURA;
    }

    public int getID_PRODUCTO() {
        return ID_PRODUCTO;
    }

    public void setID_PRODUCTO(int ID_PRODUCTO) {
        this.ID_PRODUCTO = ID_PRODUCTO;
    }

    public int getCANTIDAD() {
        return CANTIDAD;
    }

    public void setCANTIDAD(int CANTIDAD) {
        if (CANTIDAD > 0 && CANTIDAD <= 99999999) {
            this.CANTIDAD = CANTIDAD;
        } else {
            System.out.println("La CANTIDAD debe de conecter datos o debe de ser numerico");
        }
    }

    public int getVALOR_PRODUCTO() {
        return VALOR_PRODUCTO;
    }

    public void setVALOR_PRODUCTO(int VALOR_PRODUCTO) {
        if (VALOR_PRODUCTO > 0 && VALOR_PRODUCTO <= 99999999) {
            this.VALOR_PRODUCTO = VALOR_PRODUCTO;
        } else {
            System.out.println("El VALOR Del PRODUCTO debe de conecter datos o debe de ser numerico");
        }
    }

    public int getTOTAL_PRODUCTO() {
        return TOTAL_PRODUCTO;
    }

    public void setTOTAL_PRODUCTO(int TOTAL_PRODUCTO) {
        if (TOTAL_PRODUCTO > 0 && TOTAL_PRODUCTO <= 99999999) {
            this.TOTAL_PRODUCTO = TOTAL_PRODUCTO;
        } else {
            System.out.println("El TOTAL Del PRODUCTO debe de conecter datos o debe de ser numerico");
        }
    }
    
    
}
