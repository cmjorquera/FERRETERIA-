/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Factura {
    private int ID_FACTURA;
    private String RUT_EMPRESA;
    private int ID_FORMA_PAGO;
    private int ID_ENTREGA;
    private int TOTAL_NETO;
    private int IVA;
    private int TOTAL_BRUTO;

    public Factura(int ID_FACTURA, String RUT_EMPRESA, int ID_FORMA_PAGO, int ID_ENTREGA, int TOTAL_NETO, int IVA, int TOTAL_BRUTO) {
        this.setID_FACTURA(ID_FACTURA);
        this.setRUT_EMPRESA(RUT_EMPRESA);
        this.setID_FORMA_PAGO(ID_FORMA_PAGO);
        this.setID_ENTREGA(ID_ENTREGA);
        this.setTOTAL_NETO(TOTAL_NETO);
        this.setIVA(IVA);
        this.setTOTAL_BRUTO(TOTAL_BRUTO);
    }

    public Factura() {
    }

    public int getID_FACTURA() {
        return ID_FACTURA;
    }

    public void setID_FACTURA(int ID_FACTURA) {
        this.ID_FACTURA = ID_FACTURA;
    }

    public String getRUT_EMPRESA() {
        return RUT_EMPRESA;
    }

    public void setRUT_EMPRESA(String RUT_EMPRESA) {
        if (RUT_EMPRESA.trim().length() >= 1 && RUT_EMPRESA.length() <= 30) {
            this.RUT_EMPRESA = RUT_EMPRESA;
        } else {
            System.out.println("El Rut de la Empresa es un campo obligatorio");
        }
    }

    public int getID_FORMA_PAGO() {
        return ID_FORMA_PAGO;
    }

    public void setID_FORMA_PAGO(int ID_FORMA_PAGO) {
        this.ID_FORMA_PAGO = ID_FORMA_PAGO;
    }

    public int getID_ENTREGA() {
        return ID_ENTREGA;
    }

    public void setID_ENTREGA(int ID_ENTREGA) {
        this.ID_ENTREGA = ID_ENTREGA;
    }

    public int getTOTAL_NETO() {
        return TOTAL_NETO;
    }

    public void setTOTAL_NETO(int TOTAL_NETO) {
        this.TOTAL_NETO = TOTAL_NETO;
    }

    public int getIVA() {
        return IVA;
    }

    public void setIVA(int IVA) {
        this.IVA = IVA;
    }

    public int getTOTAL_BRUTO() {
        return TOTAL_BRUTO;
    }

    public void setTOTAL_BRUTO(int TOTAL_BRUTO) {
        this.TOTAL_BRUTO = TOTAL_BRUTO;
    }
    
    
}
