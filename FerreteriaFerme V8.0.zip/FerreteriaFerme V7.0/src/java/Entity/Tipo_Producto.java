/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author josemanuel
 */
public class Tipo_Producto {

    private int ID_TIPO_PRODUCTO;
    private String DESCRIPCION;

    public Tipo_Producto(int ID_TIPO_PRODUCTO, String DESCRIPCION) {
        this.setID_TIPO_PRODUCTO(ID_TIPO_PRODUCTO);
        this.setDESCRIPCION(DESCRIPCION);
    }

    public int getID_TIPO_PRODUCTO() {
        return ID_TIPO_PRODUCTO;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public void setID_TIPO_PRODUCTO(int ID_TIPO_PRODUCTO) {
        this.ID_TIPO_PRODUCTO = ID_TIPO_PRODUCTO;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        if (DESCRIPCION.trim().length() > 0 && DESCRIPCION.length() <= 30) {
            this.DESCRIPCION = DESCRIPCION;
        } else {
            System.out.println("La descripcion es un campo obligatorio");
        }

    }

}
