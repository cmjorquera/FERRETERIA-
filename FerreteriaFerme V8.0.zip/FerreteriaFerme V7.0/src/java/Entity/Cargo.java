/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Cargo {
    private int ID_CARGO;
    private String DESCRIPCION;

    public Cargo(int ID_CARGO, String DESCRIPCION) {
        this.ID_CARGO = ID_CARGO;
        this.DESCRIPCION = DESCRIPCION;
    }

    public Cargo() {
    }

    public int getID_CARGO() {
        return ID_CARGO;
    }

    public void setID_CARGO(int ID_CARGO) {
        this.ID_CARGO = ID_CARGO;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        if (DESCRIPCION.trim().length() > 0 && DESCRIPCION.length() <= 30) {
            this.DESCRIPCION = DESCRIPCION;
        } else {
            System.out.println("La descripcion es un campo obligatorio");
        }

    }
    
    
    
}
