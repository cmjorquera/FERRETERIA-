/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author josemanuel
 */
public class Nivel_usuario {

    private int ID_NIVEL_USUARIO;
    private String DESCRIPCION;

    public Nivel_usuario(int ID_NIVEL_USUARIO, String DESCRIPCION) {
        this.setID_NIVEL_USUARIO(ID_NIVEL_USUARIO);
        this.setDESCRIPCION(DESCRIPCION);
    }

    public int getID_NIVEL_USUARIO() {
        return ID_NIVEL_USUARIO;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public void setID_NIVEL_USUARIO(int ID_NIVEL_USUARIO) {
        this.ID_NIVEL_USUARIO = ID_NIVEL_USUARIO;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        if (DESCRIPCION.trim().length() >= 1 && DESCRIPCION.length() <= 30) {
            this.DESCRIPCION = DESCRIPCION;
        } else {
            System.out.println("la descripcion es un campo obligatorio");
        }
    }

}
