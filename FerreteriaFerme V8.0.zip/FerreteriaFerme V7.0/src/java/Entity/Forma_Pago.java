/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;

/**
 *
 * @author josemanuel
 */
public class Forma_Pago {

    private int ID_FORMA_PAGO;
    private String DESCRIPCION;

    public Forma_Pago(int ID_FORMA_PAGO, String DESCRIPCION) {
        this.setID_FORMA_PAGO(ID_FORMA_PAGO);
        this.setDESCRIPCION(DESCRIPCION);
    }

    public int getID_FORMA_PAGO() {
        return ID_FORMA_PAGO;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public void setID_FORMA_PAGO(int ID_FORMA_PAGO) {
        this.ID_FORMA_PAGO = ID_FORMA_PAGO;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        if (DESCRIPCION.trim().length() >= 1 && DESCRIPCION.length() <= 30) {
            this.DESCRIPCION = DESCRIPCION;
        } else {
            System.out.println("la descripcion es un campo obligatorio");
        }
    }

}
