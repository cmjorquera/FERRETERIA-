/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Entrega {
    private int ID_ENTREGA;
    private String DESCRIPCION;

    public Entrega(int ID_ENTREGA, String DESCRIPCION) {
        this.setID_ENTREGA(ID_ENTREGA);
       this.setDESCRIPCION(DESCRIPCION);
    }

    public Entrega() {
    }

    public int getID_ENTREGA() {
        return ID_ENTREGA;
    }

    public void setID_ENTREGA(int ID_ENTREGA) {
        this.ID_ENTREGA = ID_ENTREGA;
    }

    public String getDESCRIPCION() {
        return DESCRIPCION;
    }

    public void setDESCRIPCION(String DESCRIPCION) {
        if (DESCRIPCION.trim().length() >= 1 && DESCRIPCION.length() <= 30) {
            this.DESCRIPCION = DESCRIPCION;
        } else {
            System.out.println("La DESCRIPCION es un campo obligatorio");
        }
    }
    
    
}
