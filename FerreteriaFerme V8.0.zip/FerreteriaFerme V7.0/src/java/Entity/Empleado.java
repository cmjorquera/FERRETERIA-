/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entity;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author Duoc
 */
public class Empleado {
    private String RUT; 
    private String NOMBRE;
    private String APELLIDO;
    private int ID_CARGO;

    public Empleado(String RUT, String NOMBRE, String APELLIDO, int ID_CARGO) {
        this.setRUT(RUT);
        this.setNOMBRE(NOMBRE);
        this.setAPELLIDO(APELLIDO);
        this.setID_CARGO(ID_CARGO);
    }

    public Empleado() {
    }

    public String getRUT() {
        return RUT;
    }

    public void setRUT(String RUT) {
       if (RUT.trim().length() >= 1 && RUT.length() <= 13) {
            this.RUT = RUT;
        } else {
            System.out.println("El Rut es un campo obligatorio");
        }
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    public void setNOMBRE(String NOMBRE) {
        if (NOMBRE.trim().length() >= 1 && NOMBRE.length() <= 30) {
            this.NOMBRE = NOMBRE;
        } else {
            System.out.println("El Nombre es un campo obligatorio");
        }
    }

    public String getAPELLIDO() {
        return APELLIDO;
    }

    public void setAPELLIDO(String APELLIDO) {
        if (APELLIDO.trim().length() >= 1 && APELLIDO.length() <= 30) {
            this.APELLIDO = APELLIDO;
        } else {
            System.out.println("El Nombre es un campo obligatorio");
        }
    }

    public int getID_CARGO() {
        return ID_CARGO;
    }

    public void setID_CARGO(int ID_CARGO) {
        this.ID_CARGO = ID_CARGO;
    }
    
    
}
