/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

/**
 *
 * @author black
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Contexto.Conexion;
import Entity.*;

public class DaoAdmProducto {

    //idd IN NUMBER,proveedor IN NUMBER,familia IN NUMBER,tipo IN NUMBER,
    //vencimiento IN DATE,des IN VARCHAR2,stck IN NUMBER,scritico IN NUMBER,preci IN NUMBER, img IN VARCHAR2
    private final Connection conex;

    public DaoAdmProducto() {
        conex = new Conexion().Obtener();

    }

    public boolean AgregarProducto(Producto pro) {
        try {
            CallableStatement stmt = conex.prepareCall("{call PRODUCTO_PKG.INSERTAR(?,?,?,?,TO_DATE(?,'YYYY-MM-DD'),?,?,?,?,?)}");
            stmt.setString(1, pro.getID_PRODUCTO() + recuperarUltimo());
            stmt.setString(2, pro.getID_PROVEEDOR());
            stmt.setInt(3, pro.getID_FAMILIA_PRODUCTO());
            stmt.setInt(4, pro.getID_TIPO_PRODUCTO());
            stmt.setString(5, pro.getFECHA_VENCIMIENTO());
            stmt.setString(6, pro.getDESCRIPCION());
            stmt.setInt(7, pro.getSTOCK());
            stmt.setInt(8, pro.getSTOCK_CRITICO());
            stmt.setInt(9, pro.getPRECIO());
            stmt.setString(10, pro.getImg());

            stmt.execute();
            return true;
        } catch (Exception e) {
            System.out.println("Error al Agregar el producto : " + e.getMessage());
            return false;
        }
    }

    private int recuperarUltimo() {
        try {
            CallableStatement stmt = conex.prepareCall("{call PRODUCTO_PKG.ULTIMO(?)}");
            stmt.registerOutParameter(1, java.sql.Types.INTEGER);
            stmt.executeUpdate();
            return stmt.getInt(1) + 1;
        } catch (Exception e) {
            System.out.println("Error al encontrar Ultimo: " + e.getMessage());
            return 0;
        }
    }

    public boolean EliminarProducto(String codigo) {
        try {
            CallableStatement stmt = conex.prepareCall("{call PRODUCTO_PKG.ELIMINAR(?,?)}");
            stmt.setString(1, codigo);

            stmt.registerOutParameter(2, java.sql.Types.INTEGER);
            stmt.executeUpdate();

            if (stmt.getInt(2) > 0) {
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            System.out.println("Error al eliminar el Productp: " + e.getMessage());
            return false;
        }
    }

    public boolean AgregarFoto(String user, String url) {
        try {
            CallableStatement stmt = conex.prepareCall("UPDATE PRODUCTO SET IMAGEN = ? where ID_PROD = ?");
            stmt.setString(1, url);
            stmt.setString(2, user);
            stmt.execute();
            return true;

        } catch (Exception e) {
            System.out.println("Error al Agregar la foto : " + e.getMessage());
            return false;
        }
    }

    
    //call PRODUCTO_PKG.ACTUALIZAR
    //(PROVEEDOR=>P/*VARCHAR2*/,FAMILIA=>F/*NUMBER*/,TIPO=>T/*NUMBER*/,VENCIMIENTO=>V/*DATE*/,
    //DES=>D/*VARCHAR2*/,STCK=>S/*NUMBER*/,SCRITICO=>S/*NUMBER*/,PRECI=>P/*NUMBER*/,IDD=>I/*VARCHAR2*/,IMG=>I/*VARCHAR2*/)
    //proveedor IN VARCHAR2,familia IN NUMBER,tipo IN NUMBER,vencimiento IN DATE,
    //des IN VARCHAR2,stck IN NUMBER,scritico IN NUMBER,preci IN NUMBER, idd IN VARCHAR2, img IN VARCHAR2
    //
    public boolean ModificarProducto(ProductoEn pro) {
        try {
            CallableStatement stmt = conex.prepareCall("{call PRODUCTO_PKG.ACTUALIZAR(?,?,?,TO_DATE(?,'YYYY-MM-DD'),?,?,?,?,?,?)}");
            stmt.setString(1, pro.getID_PROVEEDOR());
            stmt.setInt(2, pro.getID_FAMILIA_PRODUCTO());
            stmt.setInt(3, pro.getID_TIPO_PRODUCTO());
            stmt.setString(4, pro.getFECHA_VENCIMIENTO());
            stmt.setString(5, pro.getDESCRIPCION());
            stmt.setInt(6, pro.getSTOCK());
            stmt.setInt(7, pro.getSTOCK_CRITICO());
            stmt.setInt(8, pro.getPRECIO());
            stmt.setString(9, pro.getID_PRODUCTO());
            stmt.setString(10, null);

            stmt.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Error al Modificar el producto : " + e.getMessage());
            return false;
        }
    }

    public boolean AumentarPedido(String codigo, String cantidad) {
        try {
            CallableStatement stmt = conex.prepareCall("UPDATE PRODUCTO SET stock = stock + ? where ID_PROD = ?");
            stmt.setString(1, cantidad);
            stmt.setString(2, codigo);
            stmt.execute();
            return true;
        } catch (Exception e) {
            System.out.println("Error al Agregar la foto : " + e.getMessage());
            return false;
        }
    }
}
