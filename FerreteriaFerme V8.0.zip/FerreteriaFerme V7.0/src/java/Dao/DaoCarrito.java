/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Contexto.Conexion;
import Entity.Boleta;
import Entity.Cliente;
import Entity.ProductoEn;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author Black
 */
public class DaoCarrito {

    private final Connection conex;

    public DaoCarrito() {
        conex = new Conexion().Obtener();

    }

    public boolean Agregar(ArrayList<ProductoEn> producto, int TipoPago, int TipoEntrega, int total, String RutCliente) {
        try {

            if (AgregarBoleta(RutCliente, TipoPago, TipoEntrega, total)) {

                ArrayList<ProductoEn> ListProducto = producto;
                for (int i = 0; i < ListProducto.size(); i++) {
                    CallableStatement stmt = conex.prepareCall("{call DSC_COMP_BOL_PKG.INSERTAR(?,?,?,?,?)}");
                    stmt.setInt(1, RecuperarUltimo());
                    stmt.setString(2, ListProducto.get(i).getID_PRODUCTO());
                    stmt.setInt(3, ListProducto.get(i).getSTOCK());
                    stmt.setInt(4, ListProducto.get(i).getPRECIO());
                    stmt.setInt(5, total);
                    stmt.execute();
                }
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Ocurrio un error al agregar el detalle de la boleta: " + e.getMessage());
            return false;
        }
    }

    public Boleta recuperarBoleta() {

        Boleta boletaRecuperada = new Boleta();
        try {
            int ultimaBoleta = RecuperarUltimo();
            PreparedStatement stmt = conex.prepareStatement("Select ID_BOLETA,RUT_CLIENTE,ID_FORMA_PAGO,ID_ENTREGA,TOTAL from Boleta where id_boleta=?");
            stmt.setInt(1, ultimaBoleta);
            ResultSet re = stmt.executeQuery();
            while (re.next()) {
              
                boletaRecuperada.setID_BOLETA(Integer.parseInt(re.getString("ID_BOLETA")));
                boletaRecuperada.setRUT_CLIENTE(re.getString("RUT_CLIENTE"));
                boletaRecuperada.setID_FORMA_PAGO(Integer.parseInt(re.getString("ID_FORMA_PAGO")));
                boletaRecuperada.setID_ENTREGA(Integer.parseInt(re.getString("ID_ENTREGA")));
                boletaRecuperada.setTOTAL(Integer.parseInt(re.getString("TOTAL")));
                return boletaRecuperada;
            }

        } catch (Exception e) {
        }

        return boletaRecuperada;

    }
    
    public Cliente recuperarCliente(String rutCliente) {

        Cliente cl = new Cliente();
        try {

            CallableStatement stmt = conex.prepareCall("SELECT NOMBR,APELLIDO,DIRECCION FROM CLIENTE WHERE RUT=?");
            stmt.setString(1, rutCliente);
            ResultSet re = stmt.executeQuery();
            while (re.next()) {

                cl.setNOMBRE(re.getString("NOMBR"));
                cl.setAPELLIDO(re.getString("APELLIDO"));
                 cl.setDIRECCION(re.getString("DIRECCION"));
                return cl;
            }

        } catch (Exception e) {

            //number varchar
            System.out.println("Error recupèrar el cliente: " + e.getMessage());

        }
        return cl;
    }
    
    

    private boolean AgregarBoleta(String rutClie, int PagoTipo, int TipoEntrega, int Total) {
        try {

            CallableStatement stmt = conex.prepareCall("{call BOLETA_PKG.INSERTAR(?,?,?,?,?)}");
            stmt.setInt(1, RecuperarUltimoBoleta());
            stmt.setString(2, rutClie);
            stmt.setInt(3, PagoTipo);
            stmt.setInt(4, TipoEntrega);
            stmt.setInt(5, Total);
            stmt.executeUpdate();
            return true;

        } catch (Exception e) {

            //number varchar
            System.out.println("Error al agregar la boleta: " + e.getMessage());
            return false;
        }
    }

    private int RecuperarUltimoBoleta() {
        try {
            CallableStatement stmt = conex.prepareCall("{call BOLETA_PKG.ULTIMO(?)}");
            stmt.registerOutParameter(1, java.sql.Types.INTEGER);
            stmt.executeUpdate();
            return stmt.getInt(1) + 1;
        } catch (Exception e) {
            System.out.println("Error al encontrar Ultimo: " + e.getMessage());
            return 0;
        }
    }

    private int RecuperarUltimo() {
        try {
            CallableStatement stmt = conex.prepareCall("{call BOLETA_PKG.ULTIMO(?)}");
            stmt.registerOutParameter(1, java.sql.Types.INTEGER);
            stmt.executeUpdate();
            return stmt.getInt(1);
        } catch (Exception e) {
            System.out.println("Error al encontrar Ultimo: " + e.getMessage());
            return 0;
        }

    }

    public boolean AgregarFactura(ArrayList<ProductoEn> ListPro, int TipoPago, int TipoEntrega, int Total, String rut) {
        try {
            if (AgregarF(rut, TipoPago, TipoEntrega, Total)) {
                for (int i = 0; i < ListPro.size(); i++) {
                    //call DSC_COMP_FAC_PKG.INSERTAR(FACTURA=>F/*NUMBER*/,PRODUCTO=>P/*VARCHAR2*/,CANT=>C/*NUMBER*/,VALOR=>V/*NUMBER*/,TOTAL=>T/*NUMBER*/);

                    //FACTURA=>F/*NUMBER*/,PRODUCTO=>P/*VARCHAR2*/,CANT=>C/*NUMBER*/,VALOR=>V/*NUMBER*/,TOTAL=>T/*NUMBER*/
                    CallableStatement stmt = conex.prepareCall("{call DSC_COMP_FAC_PKG.INSERTAR(?,?,?,?,?)}");
                    stmt.setInt(1, UltimoFacturaDST());
                    stmt.setString(2, ListPro.get(i).getID_PRODUCTO());
                    stmt.setInt(3, 1);
                    stmt.setInt(4, ListPro.get(i).getPRECIO());
                    stmt.setInt(5, Total);
                    stmt.execute();
                }
                return true;

            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error al agregar el detalle da la factura  : " + e.getMessage());
            return false;
        }
    }

    private boolean AgregarF(String rut, int TipoPago, int TipoEntrega, int Total) {
        try {
            //IDD=>I/*NUMBER*/,RUTT=>R/*VARCHAR2*/,PAGO=>P/*NUMBER*/,ENTREGA=>E/*NUMBER*/,NETO=>N/*NUMBER*/,IVAA=>I/*NUMBER*/,BRUTO=>B/*NUMBER*/
            CallableStatement stmt = conex.prepareCall("{call FACTURA_PKG.INSERTAR(?,?,?,?,?,?,?)}");
            stmt.setInt(1, UltimoFactura());
            stmt.setString(2, rut);
            stmt.setInt(3, TipoPago);
            stmt.setInt(4, TipoEntrega);
            stmt.setInt(5, CalcularNeto(Total));
            stmt.setInt(6, CalcularIVA(Total));
            stmt.setInt(7, Total);
            stmt.execute();
            return true;
        } catch (Exception e) {
            System.out.println("Error al agregar la factura: " + e.getMessage());
            return false;
        }
    }

    private int UltimoFactura() {
        try {
            CallableStatement stmt = conex.prepareCall("{call FACTURA_PKG.ULTIMO(?)}");
            stmt.registerOutParameter(1, java.sql.Types.INTEGER);
            stmt.executeUpdate();
            return stmt.getInt(1) + 1;
        } catch (Exception e) {
            System.out.println("Error al encontrar Ultimo factura: " + e.getMessage());
            return 0;
        }
    }

    private int CalcularNeto(int Total) {
        try {
            int neto = (int) (Total * 0.81);

            return neto;
        } catch (Exception e) {
            System.out.println("Error al calcular valor neto :" + e.getMessage());
            return 0;
        }
    }

    private int CalcularIVA(int Total) {
        try {
            int neto = (int) (Total * 0.19);
            return neto;
        } catch (Exception e) {
            System.out.println("Error al calcular valor del IVA :" + e.getMessage());
            return 0;
        }
    }

    private int UltimoFacturaDST() {
        try {
            CallableStatement stmt = conex.prepareCall("{call FACTURA_PKG.ULTIMO(?)}");
            stmt.registerOutParameter(1, java.sql.Types.INTEGER);
            stmt.executeUpdate();
            return stmt.getInt(1);
        } catch (Exception e) {
            System.out.println("Error al encontrar Ultimo: " + e.getMessage());
            return 0;
        }
    }
}
