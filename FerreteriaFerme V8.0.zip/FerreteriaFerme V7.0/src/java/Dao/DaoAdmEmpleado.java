/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Contexto.Conexion;
import Entity.*;

/**
 *
 * @author black
 */
public class DaoAdmEmpleado {

    private final Connection conex;

    public DaoAdmEmpleado() {
        conex = new Conexion().Obtener();

    }

    public boolean AgregarEmpleado(Usuario user, Empleado emp) {
        try {
            CallableStatement stmt = conex.prepareCall("{call EMPLEADO_PKG.INSERTAR(?,?,?,?)}");
            stmt.setString(1, emp.getRUT());
            stmt.setString(2, emp.getNOMBRE());
            stmt.setString(3, emp.getAPELLIDO());
            stmt.setInt(4, emp.getID_CARGO());

            if (AgregarUsuario(user, emp)) {
                stmt.execute();
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            System.out.println("Error al agregar el empleado : " + e.getMessage());
            return false;
        }
    }

    public boolean AgregarUsuario(Usuario user, Empleado emp) {
        try {

            CallableStatement stmtu = conex.prepareCall("{CALL USUARIO_PKG.INSERTAR(?,?,?,?)}");

            stmtu.setString(1, emp.getRUT());
            stmtu.setString(2, user.getUSER());
            stmtu.setString(3, user.getPASS());
            stmtu.setInt(4, user.getID_NIVEL_USUARIO());

            stmtu.execute();
            return true;

        } catch (Exception ex) {
            System.out.println("Error al agregar el usuario" + ex.getMessage());
            return false;
        }

    }

     public boolean ModificarEmpleado(Usuario user, Empleado emp) {
        try {

            CallableStatement stmtu = conex.prepareCall("{CALL EMPLEADO_PKG.ACTUALIZAR(?,?,?,?)}");
            
            
            stmtu.setString(1, emp.getNOMBRE());
            stmtu.setString(2, emp.getAPELLIDO());
            stmtu.setInt(3, emp.getID_CARGO());
            stmtu.setString(4, emp.getRUT());
            

            
              if (ModificarUsuario(user, emp)) {
                stmtu.execute();
                return true;
            } else {
                return false;
            }
           

        } catch (Exception ex) {
            System.out.println("Error al Modificar el usuario" + ex.getMessage());
            return false;
        }

    }
	
	public boolean ModificarUsuario(Usuario user, Empleado emp) {
        try {

            CallableStatement stmtu = conex.prepareCall("{CALL USUARIO_PKG.ACTUALIZAR(?,?,?,?)}");

            
            stmtu.setString(1, user.getUSER());
            stmtu.setString(2, user.getPASS());
            stmtu.setInt(3, user.getID_NIVEL_USUARIO());
            stmtu.setString(4, emp.getRUT());

          stmtu.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Error al Modificar el usuario" + ex.getMessage());
            return false;
        }

    }
	
    public boolean EliminarUsuarioEmp(String rut) {
        try {
            CallableStatement stmt = conex.prepareCall("{call USUARIO_PKG.ELIMINAR(?,?)}");
            stmt.setString(1, rut);
            stmt.registerOutParameter(2, java.sql.Types.INTEGER);

            if (EliminarEmpleado(rut)) {
                stmt.executeUpdate();
                if (stmt.getInt(2) > 0) {
                    return true;
                } else {
                    return false;
                }

            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error al eliminar el Empleado: " + e.getMessage());
            return false;
        }
    }

    private boolean EliminarEmpleado(String rut) {
        try {
            CallableStatement stmt = conex.prepareCall("{call EMPLEADO_PKG.ELIMINAR(?,?)}");
            stmt.setString(1, rut);
            stmt.registerOutParameter(2, java.sql.Types.INTEGER);

            stmt.executeUpdate();

            if (stmt.getInt(2) > 0) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error al eliminar el usuario : " + e.getMessage());
            return false;
        }
    }

}
