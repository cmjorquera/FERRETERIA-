/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

/**
 *
 * @author pepe_
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Contexto.Conexion;
import Entity.*;

public class DaoLogin {

    private final Connection conex;

    public DaoLogin() {
        conex = new Conexion().Obtener();

    }

    public boolean AgregarCliente(Usuario user, Cliente clie) {
        try {
            if (AgregarUsuario(user, clie)) {
                CallableStatement stmt = conex.prepareCall("{call CLIENTE_PKG.INSERTAR(?,?,?,?,?,?,TO_DATE(?,'YYYY-MM-DD'))}");
                stmt.setString(1, clie.getRUT());
                stmt.setString(2, clie.getNOMBRE());
                stmt.setString(3, clie.getAPELLIDO());
                stmt.setString(4, clie.getDIRECCION());
                stmt.setString(5, clie.getCOMUNA());
                stmt.setString(6, clie.getEMAIL());
                stmt.setString(7, clie.getFECHA_NACIMIENTO());

                stmt.execute();
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error al agregar el Cliente Excepcion" + e.getMessage());
            return false;
        }
    }

    public boolean AgregarEmpresa(Usuario user, Empresa emp) {
        try {
            if (AgregarUsuarioE(user, emp)) {
                //call (RUTT=>R/*VARCHAR2*/,NOM=>N/*VARCHAR2*/,DIR=>D/*VARCHAR2*/,COM=>C/*NUMBER*/,CORREO=>C/*VARCHAR2*/);
                CallableStatement stmt = conex.prepareCall("{call EMPRESA_PKG.INSERTAR(?,?,?,?,?)}");
                stmt.setString(1, emp.getRUT());
                stmt.setString(2, emp.getNOMBRE());
                stmt.setString(3, emp.getDIRECCION());
                stmt.setString(4, emp.getCOMUNA());
                stmt.setString(5, emp.getEMAIL());
                stmt.execute();

                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error al agregar la empresa :" + e.getMessage());
            return false;
        }
    }

    public boolean LogearUsuario() {
        return true;
    }

    public boolean AgregarUsuario(Usuario user, Cliente clie) {
        try {

            CallableStatement stmtu = conex.prepareCall("{CALL USUARIO_PKG.INSERTAR(?,?,?,?)}");

            stmtu.setString(1, clie.getRUT());
            stmtu.setString(2, user.getUSER());
            stmtu.setString(3, user.getPASS());
            stmtu.setInt(4, user.getID_NIVEL_USUARIO());

            stmtu.execute();
            return true;

        } catch (Exception ex) {
            System.out.println("Error al agregar el usuario" + ex.getMessage());
            return false;
        }

    }

    private boolean AgregarUsuarioE(Usuario user, Empresa emp) {
        try {

            CallableStatement stmtu = conex.prepareCall("{CALL USUARIO_PKG.INSERTAR(?,?,?,?)}");

            stmtu.setString(1, emp.getRUT());
            stmtu.setString(2, user.getUSER());
            stmtu.setString(3, user.getPASS());
            stmtu.setInt(4, user.getID_NIVEL_USUARIO());

            stmtu.execute();
            return true;

        } catch (Exception ex) {
            System.out.println("Error al agregar el usuario" + ex.getMessage());
            return false;
        }
    }

    public String buscarRutUsuario(Usuario usu) {
        String bo = "";
        try {
            PreparedStatement stmt = conex.prepareStatement("select * from usuario where userr = ? and pass = ?");
            stmt.setString(1, usu.getUSER());
            stmt.setString(2, usu.getPASS());

            ResultSet re = stmt.executeQuery();

            while (re.next()) {
                bo = re.getString("ID_USUARIO");
            }

            return bo;
        } catch (Exception e) {
            System.out.println("Error al buscar el nivel del usuario Exepción : " + e.getMessage());
            return "";
        }
    }

    public int buscarNivelUsuario(Usuario usu) {
        int bo = 0;
        try {
            PreparedStatement stmt = conex.prepareStatement("select * from usuario where userr = ? and pass = ?");
            stmt.setString(1, usu.getUSER());
            stmt.setString(2, usu.getPASS());

            ResultSet re = stmt.executeQuery();

            while (re.next()) {
                bo = re.getInt("ID_NIVEL_USU");
            }

            return bo;
        } catch (Exception e) {
            System.out.println("Error al buscar el nivel del usuario Exepción : " + e.getMessage());
            return 0;
        }
    }

    public ArrayList<Usuario> login(Usuario user) {
        ArrayList<Usuario> ust = new ArrayList<>();
        try {

            CallableStatement stmt = conex.prepareCall("{call USUARIO_PKG.VALIDARUSER(?,?)}");
            //parametros de entrada
            stmt.setString(1, user.getUSER());
            stmt.setString(2, user.getPASS());
            //parametros de salida
            stmt.registerOutParameter(1, java.sql.Types.VARCHAR);
            stmt.registerOutParameter(2, java.sql.Types.VARCHAR);
            stmt.execute();

            Usuario us = new Usuario();
            us.setID_USUARIO(stmt.getString(2));
            us.setID_NIVEL_USUARIO(stmt.getInt(3));
            System.out.println(stmt.getInt(3));
            ust.add(us);

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        return ust;
    }

}
