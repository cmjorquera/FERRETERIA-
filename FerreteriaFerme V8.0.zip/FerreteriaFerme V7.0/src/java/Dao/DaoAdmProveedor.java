/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import Contexto.Conexion;
import Entity.*;

/**
 *
 * @author black
 */
public class DaoAdmProveedor {

    private final Connection conex;

    public DaoAdmProveedor() {
        conex = new Conexion().Obtener();

    }

    public boolean AgregarProveedor(Usuario usu, Proveedor pro) {
        try {
            CallableStatement stmt = conex.prepareCall("{call PROVEEDOR_PKG.INSERTAR(?,?,?,?)}");
            stmt.setString(1, pro.getRUT_PROVEEDOR());
            stmt.setString(2, pro.getNOMBRE());
            stmt.setString(3, pro.getCELULAR());
            stmt.setString(4, pro.getRUBRO());

            if (AgregarUsuario(usu, pro)) {
                stmt.execute();
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            System.out.println("Error al agregar el Proveedor en la  Excepcion: " + e.getMessage());
            return false;
        }
    }

    public boolean AgregarUsuario(Usuario user, Proveedor pro) {
        try {

            CallableStatement stmtu = conex.prepareCall("{CALL USUARIO_PKG.INSERTAR(?,?,?,?)}");

            stmtu.setString(1, pro.getRUT_PROVEEDOR());
            stmtu.setString(2, user.getUSER());
            stmtu.setString(3, user.getPASS());
            stmtu.setInt(4, user.getID_NIVEL_USUARIO());

            stmtu.execute();
            return true;

        } catch (Exception ex) {
            System.out.println("Error al agregar el usuario" + ex.getMessage());
            return false;
        }

    }

    public boolean EliminarUsuarioPro(String rut) {
        try {
            CallableStatement stmt = conex.prepareCall("{call USUARIO_PKG.ELIMINAR(?,?)}");
            stmt.setString(1, rut);
            stmt.registerOutParameter(2, java.sql.Types.INTEGER);
            if (EliminarProveedor(rut)) {
                stmt.executeUpdate();
                if (stmt.getInt(2) > 0) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            System.out.println("Error al eliminar el Usuario: " + e.getMessage());
            return false;
        }
    }

    private boolean EliminarProveedor(String rut) {
        try {
            CallableStatement stmt = conex.prepareCall("{call PROVEEDOR_PKG.ELIMINAR(?,?)}");
            stmt.setString(1, rut);
            stmt.registerOutParameter(2, java.sql.Types.INTEGER);
            stmt.executeUpdate();

            if (stmt.getInt(2) > 0) {
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            System.out.println("Error al eliminar el Proveedor : " + e.getMessage());
            return false;
        }
    }

    public boolean ModificarProveedor(Usuario usu, Proveedor pro) {
        try {
            CallableStatement stmt = conex.prepareCall("{call PROVEEDOR_PKG.ACTUALIZAR(?,?,?,?)}");

            stmt.setString(1, pro.getNOMBRE());
            stmt.setString(2, pro.getCELULAR());
            stmt.setString(3, pro.getRUBRO());
            stmt.setString(4, pro.getRUT_PROVEEDOR());

            if (ModificarUsuario(usu, pro)) {
                stmt.execute();
                return true;
            } else {
                return false;
            }

        } catch (Exception e) {
            System.out.println("Error al Modificar el Proveedor en la  Excepcion: " + e.getMessage());
            return false;
        }
    }

    public boolean ModificarUsuario(Usuario user, Proveedor pro) {
        try {

            CallableStatement stmtu = conex.prepareCall("{CALL USUARIO_PKG.ACTUALIZAR(?,?,?,?)}");

            //PROCEDURE actualizar(us IN VARCHAR2,pss IN VARCHAR2,nivel IN NUMBER,idd IN VARCHAR2);
            stmtu.setString(1, user.getUSER());
            stmtu.setString(2, user.getPASS());
            stmtu.setInt(3, user.getID_NIVEL_USUARIO());
            stmtu.setString(4, pro.getRUT_PROVEEDOR());

            stmtu.execute();
            return true;

        } catch (Exception ex) {
            System.out.println("Error al Modificar el usuario" + ex.getMessage());
            return false;
        }

    }

    public ArrayList<ProductoEn> ListarProductopro(String rut) {
        ArrayList<ProductoEn> lista = new ArrayList<>();
        try {
            CallableStatement stmt = conex.prepareCall("select * from producto where rut_prov = ?");
            stmt.setString(1, rut);
            ResultSet re = stmt.executeQuery();
            while (re.next()) {
                //,FECH_VENC,DESCRIPCION,STOCK,STOCK_CRITICO,PRECIO,IMAGEN
                ProductoEn pro = new ProductoEn(re.getString("ID_PROD"), re.getString("RUT_PROV"), re.getInt("ID_FAMPROD"), re.getInt("ID_TIPOPROD"),
                        re.getString("FECH_VENC"), re.getString("DESCRIPCION"), re.getInt("STOCK"), re.getInt("STOCK_CRITICO"),
                        re.getInt("PRECIO"), re.getString("IMAGEN"));
                lista.add(pro);

            }
            return lista;
        } catch (Exception e) {
            System.out.println("Error al listar los productos del proveedor: " + e.getMessage());
            return null;
        }
    }

}
