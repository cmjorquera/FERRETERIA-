/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Contexto;

/**
 *
 * @author pepe_
 */
import java.sql.*;

public class Conexion3 {

    private Connection cone;

    public Conexion3() {
        AbrirConexion();
    }

    private void AbrirConexion() {
        try {
            
            Class.forName("oracle.jdbc.OracleDriver");
            String url = "jdbc:oracle:thin:@localhost:1521:XE";
            String user = "FERNET";
            String pass = "fernet";
            System.out.println("Conectando..");
            cone = DriverManager.getConnection(url, user, pass);
            System.out.println("Conectado");
        } catch (Exception e) {
            System.out.println("Error al conectar : " + e.getMessage() + ". y se localiza en " + e.getLocalizedMessage());
        }
    }

    public Connection Obtener() {
        return cone;
    }
}
