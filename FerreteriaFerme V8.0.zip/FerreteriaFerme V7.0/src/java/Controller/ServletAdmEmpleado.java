/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.DaoAdmEmpleado;
import Entity.Empleado;
import Entity.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author black
 */
@WebServlet(name = "ServletAdmEmpleado", urlPatterns = {"/ServletAdmEmpleado"})
public class ServletAdmEmpleado extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs,
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String btn = request.getParameter("BtnAccion");
            DaoAdmEmpleado dao = new DaoAdmEmpleado();

            if (btn.equals("Registrar")) {
                String rut = request.getParameter("txtRut");
                String nombre = request.getParameter("txtNombre");
                String apellido = request.getParameter("txtApellido");
                int cargo = Integer.parseInt(request.getParameter("ddlCargo"));
                String user = request.getParameter("txtUser");
                String pass = request.getParameter("txtPass");
                //se cae aca
                int nivel = Integer.parseInt(request.getParameter("ddlnivel"));

                Usuario usu = new Usuario("1", user, pass, nivel);
                Empleado emp = new Empleado(rut, nombre, apellido, cargo);

                if (dao.AgregarEmpleado(usu, emp)) {
                    request.setAttribute("MsjR", "Empleado registrado");
                } else {
                    request.setAttribute("MsjR", "Empleado, usuario y/o contraseña  incorrectos/Duplicados");
                }
                request.getRequestDispatcher("AdmEmpleado.jsp").forward(request, response);
                response.sendRedirect("AdmEmpleado.jsp");
            }
            if (btn.equals("Eliminar")) {
                String rut = request.getParameter("txtRut");
                if (dao.EliminarUsuarioEmp(rut)) {
                    request.setAttribute("MsjE", "Empleado Eliminado");
                } else {
                    request.setAttribute("MsjE", "No se puede eliminar");
                }
                request.getRequestDispatcher("AdmEmpleado.jsp").forward(request, response);
                response.sendRedirect("AdmEmpleado.jsp");
            }
            if (btn.equals("Modificar")) {
                String rut = request.getParameter("ddltxtRut");
                String nombre = request.getParameter("txtNombre");
                String apellido = request.getParameter("txtApellido");
                int cargo = Integer.parseInt(request.getParameter("ddlCargo"));
                String user = request.getParameter("txtUser");
                String pass = request.getParameter("txtPass");
       
                int nivel = Integer.parseInt(request.getParameter("ddlnivel"));

                Usuario usu = new Usuario(rut, user, pass, nivel);
                Empleado emp = new Empleado(rut, nombre, apellido, cargo);

                if (dao.ModificarEmpleado(usu, emp)) {
                    request.setAttribute("MsjR", "Empleado fue Modificado");
                } else {
                    request.setAttribute("MsjR", "Empleado, No se Pudo Modificar");
                }
                request.getRequestDispatcher("AdmEmpleado.jsp").forward(request, response);
                response.sendRedirect("AdmEmpleado.jsp");
            }
        } catch (Exception e) {
            System.out.println("Error en la administracion de los usuarios ubicado en el servlet codigo :" + e.getMessage());
            request.setAttribute("MsjR", "Revise que todos los campos esten completos");
            request.getRequestDispatcher("AdmEmpleado.jsp").forward(request, response);
            response.sendRedirect("AdmEmpleado.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
