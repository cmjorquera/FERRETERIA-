/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.*;
import Entity.*;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.Barcode128;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Random;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Black
 */
@WebServlet(name = "Factura", urlPatterns = {"/Factura"})
public class Factura extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //response.setContentType("text/html;charset=UTF-8");
        response.setContentType("application/pdf");
        /* PrintWriter out = response.getWriter();*/
        HttpSession session = request.getSession();
        Document documento = new Document();
        String rut = (String) session.getAttribute("rut");

        int num = (int) (Math.random() * 10 + 1);
        Random rnd = new Random();
        int al6 = 100000 + rnd.nextInt(900000);
        String azar = "1" + al6;
        //fuente normal
        Font fuente = new Font();

        Font fuenteSub = new Font();
        fuenteSub.setSize(8);
        try {
//espacios para btener un buen diseño
            String espacio1 = "               ";//15 espacios
            String espacio2 = "     ";//5 espacios
            String espacio3 = "          ";//10 espacios
            String espacio4 = "                  ";//18 espacios
            PdfWriter pow = PdfWriter.getInstance(documento, response.getOutputStream());
            //incorporacion de Logo 
            Image imagen = Image.getInstance("c:/Captura.png");
            //tamaño en %
            imagen.scaleAbsoluteWidth(40f);
            imagen.scaleAbsoluteHeight(40f);
            //imagen.setAlignment(Image.ALIGN_RIGHT); alineacion a la derecha

            //creacion de fecha
            /* agrego fecha y doy formato*/
            Date date = Calendar.getInstance().getTime();
            DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy, hh:mm:ss a");
            String today = formatter.format(date);

            fuente.setSize(38);
            documento.open();/*abre el documento*/
            documento.add(imagen);

            //creacion de titulo
            documento.add(new Paragraph("\n"));
            documento.add(new Phrase(" Ferrateria Ferme" + espacio2, fuente));
            documento.add(new Phrase("Factura de venta y servicio\n"));
            documento.add(new Paragraph("\n"));
            documento.add(new Paragraph("(centro de herramientas)", fuenteSub));
            documento.add(new Paragraph("Av. Vikuña Makena, San Joaquin,", fuenteSub));
            documento.add(new Paragraph("Region Metropolitana.", fuenteSub));
            documento.add(new Paragraph("www.FerreteriaFerme.cl", fuenteSub));
            documento.add(new Paragraph("Fono: +569 61777202", fuenteSub));

            documento.add(new Paragraph("\n"));
            documento.add(new Paragraph(espacio4 + espacio4 + espacio4 + espacio4 + "Fecha Actual: " + today));
            documento.add(new Paragraph("Empresa: " + "RUT: " + rut));


            /* crear tabla */
            documento.add(new Paragraph(" "));
            PdfPTable table = new PdfPTable(4);
            table.setTotalWidth(new float[]{150, 110, 110, 95});
            table.setLockedWidth(true);

            PdfPCell cell;
            cell = new PdfPCell(new Paragraph("N° Producto"));
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table.addCell(cell);

            cell = new PdfPCell(new Paragraph("Producto"));
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table.addCell(cell);

            cell = new PdfPCell(new Paragraph("Cantidad"));
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table.addCell(cell);

            cell = new PdfPCell(new Paragraph("Valor"));
            cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table.addCell(cell);

            ArrayList<ProductoEn> ListPro = (ArrayList<ProductoEn>) session.getAttribute("carrito");
            //llenado la tabla de boleta 
            int total = 0;

            for (int i = 0; i < ListPro.size(); i++) {
                table.addCell(ListPro.get(i).getID_PRODUCTO());
                table.addCell(ListPro.get(i).getDESCRIPCION());
                table.addCell("1");
                table.addCell("$" + ListPro.get(i).getPRECIO());

                total = total + ListPro.get(i).getPRECIO();
            }

            documento.add(table);
            documento.add(new Paragraph(" "));
            //añadimos la nueva tabla
            PdfPTable table2 = new PdfPTable(4);
            table2.setTotalWidth(new float[]{72, 110, 110, 95});
            table2.setLockedWidth(true);

            PdfPCell cell2;
            cell2 = new PdfPCell(new Paragraph("Valor Neto"));
            cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table2.addCell(cell2);

            cell2 = new PdfPCell(new Paragraph("Valor IVA"));
            cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table2.addCell(cell2);

            cell2 = new PdfPCell(new Paragraph("Valor Bruto"));
            cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table2.addCell(cell2);

            cell2 = new PdfPCell(new Paragraph("Tipo Boleta"));
            cell2.setBackgroundColor(BaseColor.LIGHT_GRAY);
            table2.addCell(cell2);
            //llenamos la tabla
            table2.addCell("$" + Neto(total));
            table2.addCell("$" + Iva(total));
            table2.addCell("$" + total);
            table2.addCell("Factura");

            documento.add(table2);
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph(" "));
            documento.add(new Paragraph("Valor total del boucher: $" + String.valueOf(total)));
            documento.add(new Paragraph("Numero del Pedido " + azar));
            documento.add(Image.getInstance(GenerarCodigo(documento, pow, azar)));
            documento.add(new Paragraph("Gracias por preferir nuestros servicios."));
            session.setAttribute("carrito", null);
            documento.close();

        } catch (DocumentException ex) {
            ex.printStackTrace();
        }

    }

    private Image GenerarCodigo(Document documento, PdfWriter pw, String coidgo) {
        PdfContentByte cimg = pw.getDirectContent();
        Barcode128 code128 = new Barcode128();
        code128.setCode(formatearCodigo(coidgo));
        code128.setCodeType(Barcode128.CODE128);
        code128.setTextAlignment(Element.ALIGN_CENTER);

        Image image = code128.createImageWithBarcode(cimg, BaseColor.BLACK, BaseColor.BLACK);
        float scaler = ((documento.getPageSize().getWidth() - documento.leftMargin() - documento.rightMargin() - 0) / image.getWidth() * 40);
        image.scalePercent(scaler);
        image.setAlignment(Element.ALIGN_CENTER);
        return image;
    }

    private String formatearCodigo(String num) {
        NumberFormat form = new DecimalFormat("0000000");
        return form.format((num != null) ? Integer.parseInt(num) : 0000000);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private int Neto(int total) {
        try {
            int neto = (int) (total * 0.81);

            return neto;
        } catch (Exception e) {
            System.out.println("Error al calcular valor neto :" + e.getMessage());
            return 0;
        }
    }

    private int Iva(int total) {
        try {
            int neto = (int) (total * 0.19);
            return neto;
        } catch (Exception e) {
            System.out.println("Error al calcular valor del IVA :" + e.getMessage());
            return 0;
        }
    }

}
