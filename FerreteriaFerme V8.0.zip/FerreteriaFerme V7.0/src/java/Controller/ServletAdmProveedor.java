/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.*;
import Entity.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author black
 */
@WebServlet(name = "ServletAdmProveedor", urlPatterns = {"/ServletAdmProveedor"})
public class ServletAdmProveedor extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String btn = request.getParameter("BtnAccion");
            DaoAdmProveedor dao = new DaoAdmProveedor();

            if (btn.equals("Registrar")) {
                String rut = request.getParameter("txtRut");
                String nombre = request.getParameter("txtNombre");
                String celular = request.getParameter("txtCelular");
                String rubro = request.getParameter("txtRubro");
                String user = request.getParameter("txtUser");
                String pass = request.getParameter("txtPass");
                int nivel = Integer.parseInt(request.getParameter("ddlnivel"));

                Usuario usu = new Usuario("1", user, pass, nivel);
                Proveedor pro = new Proveedor(nivel, rut, nombre, celular, rubro);

                if (dao.AgregarProveedor(usu, pro)) {
                    request.setAttribute("MsjR", "Proveedor registrado");
                } else {
                    request.setAttribute("MsjR", "Proveedor, usuario y/o contraseña  incorrectos/Duplicados");
                }
                request.getRequestDispatcher("AdmProveedor.jsp").forward(request, response);
                response.sendRedirect("AdmProveedor.jsp");
            }
            if (btn.equals("Eliminar")) {
                String rut = request.getParameter("txtRut");
                if (dao.EliminarUsuarioPro(rut)) {
                    request.setAttribute("MsjE", "Proveedor Eliminado");
                } else {
                    request.setAttribute("MsjE", "No se puede eliminar");
                }
                request.getRequestDispatcher("AdmProveedor.jsp").forward(request, response);
                response.sendRedirect("AdmProveedor.jsp");
            }
            if (btn.equals("Modificar")) {
                String rut = request.getParameter("ddltxtRut");
                String nombre = request.getParameter("txtNombre");
                String celular = request.getParameter("txtCelular");
                String rubro = request.getParameter("txtRubro");
                String user = request.getParameter("txtUser");
                String pass = request.getParameter("txtPass");
                int nivel = Integer.parseInt(request.getParameter("ddlnivel"));

                Usuario usu = new Usuario(rut, user, pass, nivel);
                Proveedor pro = new Proveedor(nivel,rut, nombre, celular, rubro);

                if (dao.ModificarProveedor(usu, pro)) {
                    request.setAttribute("MsjR", "Proveedor Modificado");
                } else {
                    request.setAttribute("MsjR", "Proveedor, NO Modificado");
                }
                request.getRequestDispatcher("AdmProveedor.jsp").forward(request, response);
                response.sendRedirect("AdmProveedor.jsp");
            }
        } catch (Exception e) {
            System.out.println("Error en la administracion de los usuarios ubicado en :" + e.getMessage());
            request.setAttribute("MsjR", "Revise que todos los campos esten completos");
            request.getRequestDispatcher("AdmProveedor.jsp").forward(request, response);
            response.sendRedirect("AdmProveedor.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
