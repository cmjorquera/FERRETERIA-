/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.DaoLogin;
import Entity.Cargo;
import Entity.Cliente;
import Entity.Empresa;
import Entity.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author pepe_
 */
@WebServlet(name = "ServletLogin", urlPatterns = {"/ServletLogin"})
public class ServletLogin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession sesion = request.getSession(true);
            DaoLogin dao = new DaoLogin();
            try {
                /*Proceso del servlet*/
                String bton = request.getParameter("BtnAccion");
                //Mi crud

                int nivel;
                String nvl;
                if (bton.equals("cerrar")) {
                    sesion.setAttribute("user", null);
                    sesion.setAttribute("nivel", null);
                    sesion.setAttribute("rut", null);
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                    response.sendRedirect("index.jsp");
                    nivel = 0;
                    nvl = "";
                }
                if (bton.equals("Logear")) {

                    String User = request.getParameter("txtUser");
                    String Pass = request.getParameter("txtPass");
                    Usuario usu = new Usuario("1", User, Pass, 2);
                    //rescatando el rut del usuario
                    String rut = dao.buscarRutUsuario(usu);

                    //rescatando el nivel del usuario
                    nivel = dao.buscarNivelUsuario(usu);

                    nvl = "" + nivel;
                    usu = new Usuario(rut, User, Pass, nivel);
                    if (nivel == 1) {
                        if (dao.login(usu) != null) {
                            sesion.setAttribute("user", User);
                            sesion.setAttribute("nivel", nvl);
                            sesion.setAttribute("rut", rut);
                        } else {
                            request.setAttribute("MsjL", "Usuario Incorrecto");
                            request.getRequestDispatcher("index.jsp").forward(request, response);
                           
                        }
                        request.getRequestDispatcher("Administracion.jsp").forward(request, response);
                    
                    }
                    if (nivel == 5) {
                        //hace la consulta si existe el usuario y si es asi lo logea 
                        if (dao.login(usu) != null) {
                            sesion.setAttribute("user", User);
                            sesion.setAttribute("nivel", nvl);
                            sesion.setAttribute("rut", rut);
                        } else {
                            request.setAttribute("MsjL", "Usuario Incorrecto");
                            request.getRequestDispatcher("index.jsp").forward(request, response);
                           
                        }
                        request.getRequestDispatcher("Prohome.jsp").forward(request, response);
                       
                    }
                    if (nivel == 2) {
                        //hace la consulta si existe el usuario y si es asi lo logea 
                        if (dao.login(usu) != null) {
                            sesion.setAttribute("user", User);
                            sesion.setAttribute("nivel", nvl);
                            sesion.setAttribute("rut", rut);
                        } else {
                            request.setAttribute("MsjL", "Usuario Incorrecto");
                            request.getRequestDispatcher("index.jsp").forward(request, response);
                      
                        }
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                      
                    }
                    request.getRequestDispatcher("index.jsp").forward(request, response);
                
                }

                if (bton.equals("Registrar")) {

                    String id = request.getParameter("id");
                    if (id.equals("1")) {
                        String Rut = request.getParameter("txtRut");
                        String Nombre = request.getParameter("txtNombre");
                        String apellido = request.getParameter("txtApellido");
                        String Direccion = request.getParameter("txtDireccion");
                        String Comuna = request.getParameter("ddlComuna");
                        String Email = request.getParameter("txtEmail");
                        String FechaNaci = request.getParameter("dgtFechaNaciemiento");
                        String User = request.getParameter("txtUser");
                        String Pass = request.getParameter("txtPass");

                        Usuario user = new Usuario("1", User, Pass, 2);
                        Cliente clie = new Cliente(Rut, Nombre, apellido, Direccion, Comuna, Email, FechaNaci, 1, 1);

                        if (dao.AgregarCliente(user, clie)) {
                            request.setAttribute("MsjR", "Usuario registrado");
                        } else {
                            request.setAttribute("MsjR", "Cliente, usuario y/o contraseña  incorrectos");
                        }
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                        
                    }
                    if (id.equals("2")) {
                        String Rut = request.getParameter("txtRut");
                        String Nombre = request.getParameter("txtNombre");
                        String Direccion = request.getParameter("txtDireccion");
                        String Comuna = request.getParameter("ddlComuna");
                        String Email = request.getParameter("txtEmail");
                        String User = request.getParameter("txtUser");
                        String Pass = request.getParameter("txtPass");

                        Usuario user = new Usuario("1", User, Pass, 2);
                        Empresa emp = new Empresa(Rut, Nombre, Direccion, Comuna, Email);

                        if (dao.AgregarEmpresa(user, emp)) {
                            request.setAttribute("MsjR", "Usuario registrado");
                        } else {
                            request.setAttribute("MsjR", "Cliente, usuario y/o contraseña  incorrectos");
                        }
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                        
                    }

                }
                if (bton.equals("Eliminar")) {
                    String Rut = request.getParameter("txtRut");
                    if (true) {
                        request.setAttribute("Msj", "Usuario Eliminado");
                    } else {
                        request.setAttribute("Msj", "Error al eliminar el usuario");
                    }
                }
                if (bton.equals("Modificar")) {
                    String Rut = request.getParameter("txtRut");
                    String Nombre = request.getParameter("txtNombre");
                    String apellido = request.getParameter("txtApellido");
                    String Direccion = request.getParameter("txtDireccion");
                    String Comuna = request.getParameter("ddlComuna");
                    String Email = request.getParameter("txtEmail");
                    String FechaNaci = request.getParameter("dgtFechaNaciemiento");
                    String User = request.getParameter("txtUser");
                    String Pass = request.getParameter("txtPass");

                    Usuario user = new Usuario("1", User, Pass, 1);
                    Cliente clie = new Cliente(Rut, Nombre, apellido, Direccion, Comuna, Email, FechaNaci, 1, 1);

                    if (true) {
                        request.setAttribute("Msj", "Usuario Modificado");
                    } else {
                        request.setAttribute("Msj", "Error al modificar el usuario");
                        request.getRequestDispatcher("index.jsp").forward(request, response);
                    }
                    
                    
                }

            } catch (Exception e) {
              
                
           
            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
