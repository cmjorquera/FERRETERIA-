/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Dao.DaoCarrito;
import Entity.ProductoEn;
import Entity.Boleta;
import Entity.Cliente;
import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Paulo
 */
@WebServlet(name = "ServletCarritoCompra", urlPatterns = {"/ServletCarritoCompra"})
public class ServletCarritoCompra extends HttpServlet {

    @Override
    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        DaoCarrito dao = new DaoCarrito();
        Boleta boleta1 = new Boleta();
        ArrayList<ProductoEn> producto = new ArrayList<ProductoEn>();
        HttpSession sesion = req.getSession();
        String btn = req.getParameter("BtnAccion");

        if (btn.equals("Borrar")) {
            ArrayList<ProductoEn> contProductos = (ArrayList<ProductoEn>) sesion.getAttribute("carrito");
            String id = req.getParameter("idProducto");

            for (int i = 0; i < contProductos.size(); i++) {
                if (contProductos.get(i).getID_PRODUCTO().equals(id)) {
                    System.out.println(contProductos.size());

                    contProductos.remove(i);
                    sesion.setAttribute("carrito", contProductos);
                    req.setAttribute("MsjR", "Eliminado correctamente");
                    if (contProductos.isEmpty()) {
                        sesion.setAttribute("carrito", null);
                    }
                    req.getRequestDispatcher("Carrito.jsp").forward(req, resp);
                    resp.sendRedirect("Carrito.jsp");
                }
            }

            req.getRequestDispatcher("Carrito.jsp").forward(req, resp);
            resp.sendRedirect("Carrito.jsp");
        }
        if (btn.equals("Pagar")) {
            ArrayList<ProductoEn> ListPro = (ArrayList<ProductoEn>) sesion.getAttribute("carrito");
            String rut = (String) sesion.getAttribute("rut");

            int TipoPago = Integer.parseInt(req.getParameter("GpTipoPago"));
            int TipoEntrega = Integer.parseInt(req.getParameter("GpTipoenvio"));
            int Total = Integer.parseInt(req.getParameter("txtTotal"));
            String tipoEntrega = null;
            String tipoPago = null;

            if (TipoEntrega == 2) {

                tipoEntrega = "Despacho Docmicilio";

            } else {
                tipoEntrega = "Retiro En Tienda";
            }

            if (TipoPago == 2) {

                tipoPago = "Pago en Cuotas";

            } else {
                tipoPago = "Pago al Contado";
            }

            int TipoDocument = Integer.parseInt(req.getParameter("GpTipoDocumneto"));
            //en el caso de ser 1 se llenara como boleta
            //en el caso de ser 2 se llenara como factura
            if (TipoDocument == 1) {
                if (dao.Agregar(ListPro, TipoPago, TipoEntrega, Total, rut)) {
                    req.setAttribute("MsjR", "Boleta Registrada correctamente");
                } else {
                    req.setAttribute("MsjR", "Error al registrar La boleta");
                    req.getRequestDispatcher("Carrito.jsp").forward(req, resp);

                }
                
                Cliente cl = new Cliente();
                
                cl= dao.recuperarCliente(rut);
                req.setAttribute("cliente", cl);

                boleta1 = dao.recuperarBoleta();
                req.setAttribute("total", Total);
                req.setAttribute("tipoPago", tipoPago);
                req.setAttribute("tipoEntrega", tipoEntrega);
                req.setAttribute("lista", ListPro);
                req.setAttribute("boleta", boleta1);
                req.getRequestDispatcher("Boleta.jsp").forward(req, resp);

            }

            if (TipoDocument == 2) {
                if (dao.AgregarFactura(ListPro, TipoPago, TipoEntrega, Total, rut)) {
                    req.setAttribute("MsjR", "Factura Registrada correctamente");
                } else {
                    req.setAttribute("MsjR", "Producto, codigo incorrectos/Duplicados");
                    req.getRequestDispatcher("Carrito.jsp").forward(req, resp);

                }
                req.getRequestDispatcher("Factura").forward(req, resp);

            }
        }

        if (btn.equals("Agregar")) {

            String idProducto = req.getParameter("idProducto");
            String Descripcion = req.getParameter("Descripcion");
            int Precio = Integer.parseInt(req.getParameter("Precio"));
            int cantidad = Integer.parseInt(req.getParameter("txtCantidad"));
            ProductoEn nuevoProducto = new ProductoEn(idProducto, "x", 1, 1, "x", Descripcion, cantidad, 1, Precio, "x");

            nuevoProducto.setID_PRODUCTO(idProducto);
            nuevoProducto.setDESCRIPCION(Descripcion);
            nuevoProducto.setPRECIO(Precio);
            nuevoProducto.setSTOCK(cantidad);

            if (sesion.getAttribute("carrito") == null) {

                producto.add(nuevoProducto);

                sesion.setAttribute("carrito", producto);

                resp.sendRedirect("Carrito.jsp");

            } else {

                ArrayList<ProductoEn> contProductos = (ArrayList<ProductoEn>) sesion.getAttribute("carrito");
                contProductos.add(nuevoProducto);

                sesion.setAttribute("carrito", contProductos);

                resp.sendRedirect("Carrito.jsp");

            }
        }

    }

    public void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        resp.sendRedirect("index.jsp");

    }

    /* ACA ACCION DE ELIMINAR PRODUCTO DEL CARRO DE COMPRA */
 /*
    
    int idProducto = Integer.parseInt(req.getParameter("idProducto"));
           
    for(int i=0; i<contProductos.size(); i++){
               
        if(contProductos.get(i).getID_PRODUCTO() == idProducto){
            contProductos.remove(i);
        }
               
    }
          
    sesion.setAttribute("carrito", contProductos);
   
     */
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
