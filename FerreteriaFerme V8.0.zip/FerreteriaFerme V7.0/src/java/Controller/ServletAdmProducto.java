/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Entity.*;
import Dao.DaoAdmProducto;

/**
 *
 * @author black
 */
@WebServlet(name = "ServletAdmProducto", urlPatterns = {"/ServletAdmProducto"})
public class ServletAdmProducto extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {

            String btn = request.getParameter("BtnAccion");
            DaoAdmProducto dao = new DaoAdmProducto();

            if (btn.equals("Registrar")) {
                String codigo = request.getParameter("txtCodigo");
                String rutPro = request.getParameter("ddlProveedor");
                int familia = Integer.parseInt(request.getParameter("ddlFamilia"));//int
                int TipoProducto = Integer.parseInt(request.getParameter("ddlTipoProducto"));//int
                String FechaVencimiento = request.getParameter("txtFechaVencimiento");
                String Descipcion = request.getParameter("txtDescripcion");
                int Stock = Integer.parseInt(request.getParameter("txtStock"));//int
                int StockCr = Integer.parseInt(request.getParameter("txtStockCri"));//int
                int precio = Integer.parseInt(request.getParameter("txtPrecio"));//

                Producto pro = new Producto(codigo, rutPro, familia, TipoProducto, FechaVencimiento, Descipcion, Stock, StockCr, precio, "/.");
                if (dao.AgregarProducto(pro)) {
                    request.setAttribute("MsjR", "Producto registrado");
                } else {
                    request.setAttribute("MsjR", "Producto, codigo incorrectos/Duplicados");
                }
                request.getRequestDispatcher("AdmProducto.jsp").forward(request, response);
                response.sendRedirect("AdmProducto.jsp");
            }
            if (btn.equals("Eliminar")) {
                String codigo = request.getParameter("txtCodigo");
                if (dao.EliminarProducto(codigo)) {
                    request.setAttribute("MsjE", "Producto Eliminado");
                } else {
                    request.setAttribute("MsjE", "No se puede eliminar");
                }
                request.getRequestDispatcher("AdmProducto.jsp").forward(request, response);
                response.sendRedirect("AdmProducto.jsp");
            }
            if (btn.equals("Modificar")) {
                String codigo = request.getParameter("txtCodigo");
                String rutPro = request.getParameter("ddlProveedor");
                int familia = Integer.parseInt(request.getParameter("ddlFamilia"));//int
                int TipoProducto = Integer.parseInt(request.getParameter("ddlTipoProducto"));//int
                String FechaVencimiento = request.getParameter("txtFechaVencimiento");
                String Descipcion = request.getParameter("txtDescripcion");
                int Stock = Integer.parseInt(request.getParameter("txtStock"));//int
                int StockCr = Integer.parseInt(request.getParameter("txtStockCri"));//int
                int precio = Integer.parseInt(request.getParameter("txtPrecio"));//

                ProductoEn pro = new ProductoEn(codigo, rutPro, familia, TipoProducto, FechaVencimiento, Descipcion, Stock, StockCr, precio, "/.");
                if (dao.ModificarProducto(pro)) {
                    request.setAttribute("MsjR", "Producto Modificado");
                } else {
                    request.setAttribute("MsjR", "Producto, NO Modificado" + pro.getFECHA_VENCIMIENTO());
                }
                request.getRequestDispatcher("AdmProducto.jsp").forward(request, response);
                response.sendRedirect("AdmProducto.jsp");
            }

            if (btn.equals("Pedir")) {
                String cantidad = request.getParameter("txtCantidad");
                String codigo = request.getParameter("txtCodigo");
                if (dao.AumentarPedido(codigo, cantidad)) {
                    request.setAttribute("MsjP", "Pedido aumentado");
                } else {
                    request.setAttribute("MsjP", "Error en el pedido");
                }
                request.getRequestDispatcher("AdmProducto.jsp").forward(request, response);
                response.sendRedirect("AdmProducto.jsp");
            }
        } catch (Exception e) {
            System.out.println("Error en la administracion de los porductos :" + e.getMessage() + " Localizacion del error :" + e.getLocalizedMessage());
            request.setAttribute("MsjR", "Revise que todos los campos esten completos");
            request.getRequestDispatcher("AdmProducto.jsp").forward(request, response);
            response.sendRedirect("AdmProducto.jsp");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
